extends Node2D
# 原创教师示范。输入→对象运动→碰撞判断→计分→结束→重开。
var playing := false
var score := 0
var lives := 3
var player_x := 360.0
var light := Vector2(360, 50)
var move_touch := 0.0
var elapsed := 0.0
var hud: Label
var action: Button
var sound: AudioStreamPlayer
func _ready() -> void:
 var layer := CanvasLayer.new()
 add_child(layer)
 hud = Label.new()
 hud.position = Vector2(22, 18)
 hud.add_theme_font_size_override("font_size", 21)
 layer.add_child(hud)
 action = Button.new()
 action.text = "开始游戏 / Start"
 action.position = Vector2(240, 210)
 action.size = Vector2(240, 60)
 action.pressed.connect(start_game)
 layer.add_child(action)
 for direction in [-1, 1]:
  var b := Button.new()
  b.text = "←" if direction == -1 else "→"
  b.position = Vector2(20 if direction == -1 else 620, 410)
  b.size = Vector2(80, 50)
  b.button_down.connect(func(): move_touch = float(direction))
  b.button_up.connect(func(): move_touch = 0.0)
  layer.add_child(b)
 sound = AudioStreamPlayer.new()
 var wav := AudioStreamWAV.new()
 wav.format = AudioStreamWAV.FORMAT_16_BITS
 wav.mix_rate = 22050
 var samples := PackedByteArray()
 samples.resize(2205 * 2)
 for i in range(2205):
  samples.encode_s16(i * 2, int(sin(i * TAU * 660.0 / 22050.0) * 2500.0 * (1.0 - i / 2205.0)))
 wav.data = samples
 sound.stream = wav
 add_child(sound)
 update_hud()
func start_game() -> void:
 score = 0
 lives = 3
 player_x = 360.0
 playing = true
 action.hide()
 light = Vector2(randf_range(40, 680), 60)
 update_hud()
func _process(delta: float) -> void:
 if playing:
  var direction := Input.get_axis("ui_left", "ui_right") + move_touch
  player_x = clampf(player_x + direction * 430.0 * delta, 45, 675)
  light.y += 220.0 * delta
  if light.y >= 365:
   if absf(light.x - player_x) < 50:
    score += 1
    sound.play()
   else:
    lives -= 1
   light = Vector2(randf_range(40, 680), 60)
   update_hud()
   if lives <= 0:
    playing = false
    action.text = "重新开始 / Restart"
    action.show()
 elapsed += delta
 if elapsed > 0.25:
  elapsed = 0
  if OS.has_feature("web"):
   JavaScriptBridge.eval("window.orbitDemo=" + JSON.stringify({"score": score, "lives": lives, "playing": playing, "playerX": player_x, "lightX": light.x, "lightY": light.y, "soundPlaying": sound.playing}))
 queue_redraw()
func update_hud() -> void:
 hud.text = "接光点  ·  分数 %d   机会 %d\n方向键或下方按钮移动，漏接三次结束" % [score, lives]
func _draw() -> void:
 draw_line(Vector2(20, 390), Vector2(700, 390), Color(0.3,0.3,0.3), 1)
 draw_rect(Rect2(player_x - 42, 365, 84, 15), Color.WHITE)
 if playing:
  draw_circle(light, 12, Color(1,0.85,0.35))
